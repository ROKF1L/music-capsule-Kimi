package com.musiccapsule.app.data.remote.spotify

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

// ---- DTO ----

@Serializable
private data class TokenResponse(
    @SerialName("access_token") val accessToken: String,
    @SerialName("expires_in") val expiresIn: Long,
)

@Serializable
private data class SearchResponse(val artists: ArtistPage? = null)

@Serializable
private data class ArtistPage(val items: List<ArtistItem> = emptyList())

@Serializable
private data class ArtistItem(
    val id: String,
    val name: String,
    val genres: List<String> = emptyList(),
    val images: List<ImageItem> = emptyList(),
)

@Serializable
private data class ImageItem(val url: String, val width: Int = 0, val height: Int = 0)

/**
 * Spotify Web API, Client Credentials Flow.
 * Используется только для поиска фото артиста высокого качества и жанров.
 */
class SpotifyApi(private val json: Json) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Токен живёт ~1 час — кэшируем в памяти, чтобы не дёргать /api/token на каждый артист
    private var cachedToken: String? = null
    private var tokenExpiresAtMs: Long = 0L

    data class ArtistResult(
        val name: String,
        val imageUrl: String?,
        val genres: String?,
    )

    /** Поиск артиста: /v1/search?q={artist}&type=artist&limit=1 */
    suspend fun searchArtist(
        artist: String,
        clientId: String,
        clientSecret: String,
    ): ArtistResult? = withContext(Dispatchers.IO) {
        if (clientId.isBlank() || clientSecret.isBlank() || artist.isBlank()) {
            return@withContext null
        }
        runCatching {
            val token = accessToken(clientId, clientSecret) ?: return@runCatching null
            val query = URLEncoder.encode(artist, Charsets.UTF_8.name())
            val request = Request.Builder()
                .url("https://api.spotify.com/v1/search?q=$query&type=artist&limit=1")
                .header("Authorization", "Bearer $token")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@runCatching null
                val parsed = json.decodeFromString<SearchResponse>(response.body.string())
                val found = parsed.artists?.items?.firstOrNull() ?: return@runCatching null
                ArtistResult(
                    name = found.name,
                    imageUrl = found.images.maxByOrNull { it.width }?.url,
                    genres = found.genres.take(3).joinToString(", ").ifBlank { null },
                )
            }
        }.getOrNull() // Нет сети / невалидные ключи -> null, вызывающий код возьмёт кэш Room
    }

    private fun accessToken(clientId: String, clientSecret: String): String? {
        val now = System.currentTimeMillis()
        cachedToken?.let { if (now < tokenExpiresAtMs) return it }

        val credentials = Base64.encodeToString(
            "$clientId:$clientSecret".toByteArray(),
            Base64.NO_WRAP,
        )
        val body = "grant_type=client_credentials"
            .toRequestBody("application/x-www-form-urlencoded".toMediaType())
        val request = Request.Builder()
            .url("https://accounts.spotify.com/api/token")
            .header("Authorization", "Basic $credentials")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val parsed = json.decodeFromString<TokenResponse>(response.body.string())
            cachedToken = parsed.accessToken
            // Минус 60 секунд — запас на сетевые задержки
            tokenExpiresAtMs = now + (parsed.expiresIn - 60) * 1000
            return parsed.accessToken
        }
    }
}
