package com.musiccapsule.app.data.repository

import com.musiccapsule.app.core.util.TimeSlot
import com.musiccapsule.app.core.util.endOfDayMs
import com.musiccapsule.app.core.util.startOfDayMs
import com.musiccapsule.app.data.local.dao.PlaybackDao
import com.musiccapsule.app.data.local.entity.PlaybackEventEntity
import com.musiccapsule.app.domain.model.DashboardData
import com.musiccapsule.app.domain.model.DayActivity
import com.musiccapsule.app.domain.model.LoopObsession
import com.musiccapsule.app.domain.model.MonthlyCapsule
import com.musiccapsule.app.domain.model.SlotStat
import com.musiccapsule.app.domain.model.TopArtist
import com.musiccapsule.app.domain.model.TopTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth

/**
 * Вся математика аналитики: стрики, биоритмы, топы, зацикливания, FLAC Flex.
 * Все операции выполняются на Dispatchers.IO.
 */
class StatsRepository(
    private val playbackDao: PlaybackDao,
) {

    // ---- Дашборд ----

    suspend fun dashboard(): DashboardData = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val heatmap = heatmap365()
        val streak = computeStreak()
        val todayMinutes =
            (playbackDao.totalListenedMs(today.startOfDayMs(), today.endOfDayMs()) ?: 0) / 60_000

        val currentMonth = YearMonth.now()
        val monthMinutes = (playbackDao.totalListenedMs(
            currentMonth.atDay(1).startOfDayMs(),
            today.endOfDayMs(),
        ) ?: 0) / 60_000

        // Капсула доступна за прошлый месяц, если в нём есть хоть одна запись
        val previousMonth = currentMonth.minusMonths(1)
        val prevCount = playbackDao.countEvents(
            previousMonth.atDay(1).startOfDayMs(),
            currentMonth.atDay(1).startOfDayMs() - 1,
        )
        DashboardData(
            streak = streak,
            heatmap = heatmap,
            todayMinutes = todayMinutes,
            monthMinutes = monthMinutes,
            capsuleMonth = if (prevCount > 0) previousMonth else null,
        )
    }

    /**
     * Общий стрик дней: подряд идущие дни с суммарным прослушиванием >= 15 минут.
     */
    suspend fun computeStreak(): Int = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val from = today.minusDays(400)
        val activeDays = playbackDao.dayTotals(from.startOfDayMs(), today.endOfDayMs())
            .filter { it.totalMs >= 15 * 60_000L } // порог "активного" дня — 15 минут
            .map { LocalDate.parse(it.day) }
            .toHashSet()

        var streak = 0
        var cursor = today
        // Если сегодня порог ещё не набран — стрик считаем со вчерашнего дня
        if (cursor !in activeDays) cursor = cursor.minusDays(1)
        while (cursor in activeDays) {
            streak++
            cursor = cursor.minusDays(1)
        }
        streak
    }

    /** Тепловая карта GitHub-style: минуты за каждый из последних 365 дней. */
    suspend fun heatmap365(): List<DayActivity> = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val from = today.minusDays(364)
        val totals = playbackDao.dayTotals(from.startOfDayMs(), today.endOfDayMs())
            .associate { LocalDate.parse(it.day) to it.totalMs / 60_000 }
        (0L..364L).map { offset ->
            val day = from.plusDays(offset)
            DayActivity(day, totals[day] ?: 0L)
        }
    }

    // ---- Капсула месяца ----

    suspend fun monthlyCapsule(year: Int, month: Int): MonthlyCapsule =
        withContext(Dispatchers.IO) {
            val yearMonth = YearMonth.of(year, month)
            val from = yearMonth.atDay(1).startOfDayMs()
            val to = yearMonth.plusMonths(1).atDay(1).startOfDayMs() - 1

            val totalMs = playbackDao.totalListenedMs(from, to) ?: 0L
            val topTracks = playbackDao.topTracks(from, to, 5).map {
                TopTrack(it.trackTitle, it.artistName, it.plays, it.totalMs, it.coverPath)
            }
            val topArtists = playbackDao.topArtists(from, to, 5).map { row ->
                TopArtist(
                    normalized = row.normalizedArtist,
                    displayName = row.displayName,
                    plays = row.plays,
                    totalMs = row.totalMs,
                    monthStreak = artistMonthStreak(row.normalizedArtist, yearMonth),
                    imageUrl = null, // обложки подставит ArtistRepository
                    genres = null,
                )
            }

            // Биоритмы: раскладываем почасовую активность по 4 слотам
            val byHour = playbackDao.minutesByHour(from, to).associate { it.hour to it.totalMs }
            val slots = TimeSlot.entries.map { slot ->
                SlotStat(slot, byHour.filterKeys { TimeSlot.of(it) == slot }.values.sum())
            }

            val dayTotals = playbackDao.dayTotals(from, to)
            val bestDay = dayTotals.maxByOrNull { it.totalMs }
            val loops = playbackDao.loopObsessions(from, to)
                .map { LoopObsession(it.trackTitle, it.artistName, it.plays, it.hourBucket) }

            MonthlyCapsule(
                yearMonth = yearMonth,
                totalMinutes = totalMs / 60_000,
                trackCount = playbackDao.countEvents(from, to),
                mostActiveDay = bestDay?.let { LocalDate.parse(it.day) },
                mostActiveDayMinutes = (bestDay?.totalMs ?: 0L) / 60_000,
                averagePerDayMinutes = totalMs / 60_000 / yearMonth.lengthOfMonth(),
                topTracks = topTracks,
                topArtists = topArtists,
                slotStats = slots,
                chronotype = chronotypeOf(slots),
                loops = loops,
                flacGb = flacFlexGb(totalMs),
            )
        }

    /**
     * FLAC Flex: суммарный объём несжатого аудио.
     * Средний битрейт FLAC принимаем ~950 кбит/с (типичный диапазон 900–1000).
     */
    private fun flacFlexGb(totalMs: Long): Double {
        val bytes = totalMs / 1000.0 * 950_000.0 / 8.0
        return bytes / (1024.0 * 1024.0 * 1024.0)
    }

    /** Хронотип по распределению активности: Сова / Жаворонок / Дневной слушатель. */
    private fun chronotypeOf(slots: List<SlotStat>): String {
        val total = slots.sumOf { it.ms }.coerceAtLeast(1L)
        val share = { slot: TimeSlot ->
            slots.first { it.slot == slot }.ms * 100 / total
        }
        return when {
            share(TimeSlot.NIGHT) >= 40 -> "Сова"
            share(TimeSlot.MORNING) >= 40 -> "Жаворонок"
            else -> "Дневной слушатель"
        }
    }

    /**
     * Стрик артиста: сколько месяцев подряд (включая [upto]) он входит в Топ-5 месяца.
     */
    suspend fun artistMonthStreak(normalizedArtist: String, upto: YearMonth): Int =
        withContext(Dispatchers.IO) {
            var streak = 0
            var cursor = upto
            while (streak < 24) { // ограничитель глубины перебора — 2 года
                val from = cursor.atDay(1).startOfDayMs()
                val to = cursor.plusMonths(1).atDay(1).startOfDayMs() - 1
                val top5 = playbackDao.topArtists(from, to, 5).map { it.normalizedArtist }
                if (normalizedArtist in top5) {
                    streak++
                    cursor = cursor.minusMonths(1)
                } else break
            }
            streak
        }

    // ---- История ----

    fun observeHistory(limit: Int = 1000): Flow<List<PlaybackEventEntity>> =
        playbackDao.observeHistory(limit)

    suspend fun setExcluded(id: Long, excluded: Boolean) =
        withContext(Dispatchers.IO) { playbackDao.setExcluded(id, excluded) }

    suspend fun deleteEvent(id: Long) =
        withContext(Dispatchers.IO) { playbackDao.delete(id) }
}
