package com.musiccapsule.app.tracking

import android.graphics.Bitmap
import com.musiccapsule.app.core.util.ArtistNormalizer
import com.musiccapsule.app.data.local.dao.ArtistDao
import com.musiccapsule.app.data.local.dao.PlaybackDao
import com.musiccapsule.app.data.local.entity.PlaybackEventEntity
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Calendar

/**
 * Стейт-машина сессий прослушивания.
 *
 * Жизненный цикл:
 *  - пришли метаданные нового трека -> предыдущая сессия закрывается, открывается новая;
 *  - PLAYING/PAUSED управляют счётчиком активного времени (время паузы не считается);
 *  - при закрытии сессии проверяется порог: >= 30 сек ИЛИ >= 50% длительности трека,
 *    иначе запись отбрасывается как скип;
 *  - ночное зацикливание (02:00–06:00, > 3 часов, экран погашен) -> is_sleep_session.
 *
 * Все методы вызываются из корутин сервиса, изменение состояния защищено Mutex.
 */
class PlaybackStateMachine(
    private val playbackDao: PlaybackDao,
    private val artistDao: ArtistDao,
    private val coverCache: CoverCache,
) {
    companion object {
        /** Минимальный порог засчитывания прослушивания — 30 секунд. */
        const val MIN_LISTEN_MS = 30_000L

        /** Анти-сон: суммарная длительность ночного зацикливания одного трека. */
        const val NIGHT_LOOP_LIMIT_MS = 3L * 60 * 60 * 1000
    }

    /** Открытая сессия: от старта трека до его смены или остановки плеера. */
    private class ActiveSession(
        val packageName: String,
        val title: String,
        val artist: String,
        val album: String?,
        val trackDurationMs: Long,
        var coverPath: String?,
        val startedAt: Long,
        var accumulatedMs: Long = 0L,
        var lastResumeAt: Long = 0L,
        var playing: Boolean = false,
    )

    private val mutex = Mutex()
    private var current: ActiveSession? = null

    /** Состояние экрана — нужно только для анти-сон эвристики. */
    @Volatile
    private var screenOn: Boolean = true

    fun setScreenOn(on: Boolean) {
        screenOn = on
    }

    // Счётчик ночного зацикливания одного и того же трека
    private var nightLoopKey: String? = null
    private var nightLoopCount: Int = 0

    /** Метаданные от MediaSession: смена трека или уточнение данных текущего. */
    suspend fun onTrackMetadata(
        packageName: String,
        title: String?,
        artist: String?,
        album: String?,
        durationMs: Long,
        artwork: Bitmap?,
    ) {
        if (title.isNullOrBlank()) return
        val artistName = artist?.takeIf { it.isNotBlank() } ?: "Неизвестный исполнитель"
        // Обложку из системных метаданных складываем в локальный кэш (IO внутри CoverCache)
        val coverPath = artwork?.let { coverCache.save("$artistName|$album|$title", it) }

        mutex.withLock {
            val session = current
            when {
                session == null -> {
                    current = ActiveSession(
                        packageName, title, artistName, album,
                        durationMs, coverPath, System.currentTimeMillis(),
                    )
                }
                sameTrack(session, title, artistName) -> {
                    // Тот же трек: плеер мог прислать обложку с задержкой
                    if (session.coverPath == null && coverPath != null) {
                        session.coverPath = coverPath
                    }
                }
                else -> {
                    // Смена трека: закрываем предыдущую сессию с проверкой порога
                    commitCurrentLocked()
                    current = ActiveSession(
                        packageName, title, artistName, album,
                        durationMs, coverPath, System.currentTimeMillis(),
                    )
                }
            }
        }
    }

    /** PLAYING/PAUSED: управление счётчиком активного времени. */
    suspend fun onPlaybackStateChanged(packageName: String, isPlaying: Boolean) {
        mutex.withLock {
            val session = current ?: return@withLock
            if (session.packageName != packageName) return@withLock
            val now = System.currentTimeMillis()
            if (isPlaying && !session.playing) {
                // Возобновление: запускаем отсчёт
                session.playing = true
                session.lastResumeAt = now
            } else if (!isPlaying && session.playing) {
                // Пауза: накапливаем отыгранное, время паузы НЕ засчитывается
                session.accumulatedMs += now - session.lastResumeAt
                session.playing = false
            }
        }
    }

    /** Полная остановка плеера (STOP / закрытие сессии): закрываем сессию. */
    suspend fun onSessionStopped(packageName: String) {
        mutex.withLock {
            val session = current ?: return@withLock
            if (session.packageName != packageName) return@withLock
            accumulateIfPlaying(session)
            commitCurrentLocked()
        }
    }

    /** Страховочный сброс открытой сессии (уничтожение сервиса и т.п.). */
    suspend fun flush() {
        mutex.withLock {
            current?.let { accumulateIfPlaying(it) }
            commitCurrentLocked()
        }
    }

    // ---- Внутренняя логика ----

    private fun accumulateIfPlaying(session: ActiveSession) {
        if (session.playing) {
            session.accumulatedMs += System.currentTimeMillis() - session.lastResumeAt
            session.playing = false
        }
    }

    private fun sameTrack(s: ActiveSession, title: String, artist: String): Boolean =
        s.title.equals(title, ignoreCase = true) && s.artist.equals(artist, ignoreCase = true)

    /** Фиксация прослушивания в Room, если трек прошёл порог (иначе — скип). */
    private suspend fun commitCurrentLocked() {
        val session = current ?: return
        current = null

        val listened = session.accumulatedMs
        val qualifies = listened >= MIN_LISTEN_MS ||
            (session.trackDurationMs > 0 && listened >= session.trackDurationMs / 2)
        if (!qualifies) return

        val sleepSession = updateNightLoop(session)

        // Склеиваем варианты написания артиста через алиасы (заполняет Gemini)
        val rawKey = ArtistNormalizer.normalize(session.artist)
        val canonical = artistDao.resolveAlias(rawKey) ?: rawKey

        playbackDao.insert(
            PlaybackEventEntity(
                trackTitle = session.title,
                artistName = session.artist,
                normalizedArtist = canonical,
                albumName = session.album,
                durationMs = listened,
                timestamp = session.startedAt,
                coverPath = session.coverPath,
                isSleepSession = sleepSession,
                sourcePackage = session.packageName,
            )
        )
    }

    /**
     * Анти-сон фильтр: один и тот же трек крутится по кругу в окне 02:00–06:00
     * при погашенном экране; если серия превысила 3 часа — помечаем is_sleep_session.
     */
    private fun updateNightLoop(session: ActiveSession): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val inNightWindow = hour in 2..5
        if (!inNightWindow || screenOn) {
            nightLoopKey = null
            nightLoopCount = 0
            return false
        }
        val key = ArtistNormalizer.normalize(session.artist) + "|" + session.title.lowercase()
        if (nightLoopKey == key) {
            nightLoopCount++
        } else {
            nightLoopKey = key
            nightLoopCount = 1
        }
        val estimatedLoopMs = nightLoopCount * maxOf(session.trackDurationMs, session.accumulatedMs)
        return estimatedLoopMs >= NIGHT_LOOP_LIMIT_MS
    }
}
