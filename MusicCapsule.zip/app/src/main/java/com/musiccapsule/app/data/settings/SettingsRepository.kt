package com.musiccapsule.app.data.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

data class AppSettings(
    val spotifyClientId: String = "",
    val spotifyClientSecret: String = "",
    val geminiApiKey: String = "",
    val blockedPackages: Set<String> = emptySet(),
)

/** Хранилище API-ключей и списков плееров на DataStore Preferences. */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val SPOTIFY_ID = stringPreferencesKey("spotify_client_id")
        val SPOTIFY_SECRET = stringPreferencesKey("spotify_client_secret")
        val GEMINI_KEY = stringPreferencesKey("gemini_api_key")
        val BLOCKED_PACKAGES = stringSetPreferencesKey("blocked_packages")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            spotifyClientId = prefs[Keys.SPOTIFY_ID].orEmpty(),
            spotifyClientSecret = prefs[Keys.SPOTIFY_SECRET].orEmpty(),
            geminiApiKey = prefs[Keys.GEMINI_KEY].orEmpty(),
            blockedPackages = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet(),
        )
    }

    suspend fun saveApiKeys(spotifyId: String, spotifySecret: String, geminiKey: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SPOTIFY_ID] = spotifyId.trim()
            prefs[Keys.SPOTIFY_SECRET] = spotifySecret.trim()
            prefs[Keys.GEMINI_KEY] = geminiKey.trim()
        }
    }

    suspend fun setPackageBlocked(packageName: String, blocked: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet()
            prefs[Keys.BLOCKED_PACKAGES] =
                if (blocked) current + packageName else current - packageName
        }
    }
}
