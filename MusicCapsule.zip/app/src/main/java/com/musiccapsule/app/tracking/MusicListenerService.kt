package com.musiccapsule.app.tracking

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import com.musiccapsule.app.MusicCapsuleApp
import com.musiccapsule.app.core.di.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Фоновый перехватчик воспроизведения из любых плееров
 * (Poweramp, AIMP, Musicolet, Symfonium и т.д.).
 *
 * Система запускает сервис, когда пользователь выдаёт доступ к уведомлениям.
 * Через MediaSessionManager подписываемся на все активные медиа-сессии и
 * проксируем метаданные/состояния в [PlaybackStateMachine].
 */
class MusicListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var container: AppContainer
    private var mediaSessionManager: MediaSessionManager? = null

    /** Зарегистрированные колбэки медиа-сессий: sessionToken -> callback. */
    private val callbacks = mutableMapOf<MediaSession.Token, MediaController.Callback>()

    /** Кэшированный чёрный список плееров (обновляется из настроек). */
    @Volatile
    private var blockedPackages: Set<String> = emptySet()

    /** Анти-сон эвристике нужно знать, включён ли экран. */
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            container.stateMachine.setScreenOn(intent.action != Intent.ACTION_SCREEN_OFF)
        }
    }

    override fun onCreate() {
        super.onCreate()
        container = (application as MusicCapsuleApp).container
        serviceScope.launch {
            container.settingsRepository.settings.collect {
                blockedPackages = it.blockedPackages
            }
        }
        registerReceiver(
            screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            },
        )
    }

    override fun onListenerConnected() {
        mediaSessionManager = getSystemService(MediaSessionManager::class.java)
        val component = ComponentName(this, MusicListenerService::class.java)
        runCatching {
            mediaSessionManager?.addOnActiveSessionsChangedListener(
                activeSessionsListener, component,
            )
            syncControllers(mediaSessionManager?.getActiveSessions(component).orEmpty())
        }
    }

    override fun onListenerDisconnected() {
        runCatching {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        }
    }

    private val activeSessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            syncControllers(controllers.orEmpty())
        }

    /** Подписываемся на новые медиа-сессии и забываем закрытые. */
    private fun syncControllers(controllers: List<MediaController>) {
        val activeTokens = controllers.mapTo(HashSet()) { it.sessionToken }
        val iterator = callbacks.entries.iterator()
        while (iterator.hasNext()) {
            if (iterator.next().key !in activeTokens) iterator.remove()
        }
        controllers.forEach { controller ->
            if (callbacks.containsKey(controller.sessionToken)) return@forEach
            val callback = MediaCallback(controller)
            callbacks[controller.sessionToken] = callback
            runCatching { controller.registerCallback(callback) }
            // Подключились к уже играющему плееру — сразу подхватываем состояние
            callback.push(controller.metadata, controller.playbackState)
        }
    }

    /** Колбэк одной медиа-сессии: метаданные + состояние воспроизведения. */
    private inner class MediaCallback(
        private val controller: MediaController,
    ) : MediaController.Callback() {

        fun push(metadata: MediaMetadata?, playbackState: PlaybackState?) {
            onMetadataChanged(metadata)
            onPlaybackStateChanged(playbackState)
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            metadata ?: return
            val pkg = controller.packageName
            if (pkg in blockedPackages) return
            // Обложка может лежать под разными ключами в зависимости от плеера
            val artwork = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            serviceScope.launch {
                container.stateMachine.onTrackMetadata(
                    packageName = pkg,
                    title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE),
                    artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST),
                    album = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM),
                    durationMs = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION),
                    artwork = artwork,
                )
            }
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            val pkg = controller.packageName
            if (pkg in blockedPackages) return
            when (state?.state) {
                PlaybackState.STATE_PLAYING ->
                    serviceScope.launch {
                        container.stateMachine.onPlaybackStateChanged(pkg, true)
                    }
                PlaybackState.STATE_PAUSED ->
                    serviceScope.launch {
                        container.stateMachine.onPlaybackStateChanged(pkg, false)
                    }
                PlaybackState.STATE_STOPPED, PlaybackState.STATE_NONE ->
                    serviceScope.launch { container.stateMachine.onSessionStopped(pkg) }
                else -> Unit
            }
        }

        override fun onSessionDestroyed() {
            serviceScope.launch { container.stateMachine.onSessionStopped(controller.packageName) }
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        }
        // Дожимаем открытую сессию, чтобы не потерять прослушивание
        if (::container.isInitialized) {
            runBlocking { container.stateMachine.flush() }
        }
        serviceScope.cancel()
        super.onDestroy()
    }
}
