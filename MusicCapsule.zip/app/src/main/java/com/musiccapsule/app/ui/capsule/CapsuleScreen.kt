package com.musiccapsule.app.ui.capsule

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.musiccapsule.app.ui.components.StoryProgressBar
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private const val SLIDE_COUNT = 5
private const val SLIDE_DURATION_MS = 6_000L

/**
 * Полноэкранная капсула: HorizontalPager + сторис-прогресс сверху,
 * размытый фон по обложке, тап-зоны слева/справа.
 */
@Composable
fun CapsuleScreen(viewModel: CapsuleViewModel, onBack: () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val capsule = state.capsule
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    if (state.loading || capsule == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { SLIDE_COUNT })
    var progress by remember { mutableFloatStateOf(0f) }
    val gradient = rememberCoverGradient(capsule.topTracks.firstOrNull()?.coverPath)

    // Автопереключение слайдов, как в историях
    LaunchedEffect(pagerState.currentPage) {
        progress = 0f
        val startedAt = System.currentTimeMillis()
        while (true) {
            progress = ((System.currentTimeMillis() - startedAt).toFloat() / SLIDE_DURATION_MS)
                .coerceAtMost(1f)
            if (progress >= 1f) {
                if (pagerState.currentPage < SLIDE_COUNT - 1) {
                    pagerState.animateScrollToPage(pagerState.currentPage + 1)
                }
                break // последний слайд не листаем дальше
            }
            delay(50)
        }
    }

    Box(Modifier.fillMaxSize().background(gradient)) {
        // Размытая обложка поверх градиента для глубины фона (blur доступен с API 31)
        capsule.topTracks.firstOrNull()?.coverPath?.let { path ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AsyncImage(
                    model = File(path),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .blur(60.dp),
                    alpha = 0.35f,
                )
            }
        }
        // Затемнение для читаемости текста
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))

        // Слайды
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            when (page) {
                0 -> SlideIntro(capsule, state.caption)
                1 -> SlideTopTracks(capsule)
                2 -> SlideTopArtists(capsule)
                3 -> SlideChronotype(capsule, state.archetype, state.roast)
                4 -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                ) {
                    ShareCard(capsule, state.archetype)
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = {
                            val activity = context as? Activity ?: return@Button
                            scope.launch {
                                // Экспорт итоговой карточки в PNG 1080x1920 и шеринг
                                val bitmap = ShareUtils.captureComposable(activity, 1080, 1920) {
                                    MusicCapsuleShareTheme {
                                        SlideSummary(capsule, state.archetype)
                                    }
                                }
                                if (bitmap != null) {
                                    ShareUtils.shareBitmap(
                                        context, bitmap,
                                        "capsule_${capsule.yearMonth}.png",
                                    )
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black,
                        ),
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(Modifier.padding(4.dp))
                        Text("Поделиться")
                    }
                }
            }
        }

        // Тап-зоны: левая треть — назад, правая — вперёд (центр свободен для кнопок)
        Row(Modifier.fillMaxSize()) {
            Box(
                Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) {
                    detectTapGestures {
                        if (pagerState.currentPage > 0) {
                            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                        }
                    }
                },
            )
            Box(Modifier.weight(2f).fillMaxHeight())
            Box(
                Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) {
                    detectTapGestures {
                        if (pagerState.currentPage < SLIDE_COUNT - 1) {
                            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                        }
                    }
                },
            )
        }

        // Верхняя панель: прогресс-бары + кнопка закрытия
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StoryProgressBar(
                pageCount = SLIDE_COUNT,
                currentPage = pagerState.currentPage,
                progress = progress,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onBack) {
                Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = Color.White)
            }
        }
    }
}

/** Локальная обёртка темы для оффскрин-рендера карточки шеринга. */
@Composable
private fun MusicCapsuleShareTheme(content: @Composable () -> Unit) {
    com.musiccapsule.app.ui.theme.MusicCapsuleTheme(content = content)
}
