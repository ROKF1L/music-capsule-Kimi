package com.musiccapsule.app.core.di

import android.content.Context
import androidx.room.Room
import com.musiccapsule.app.data.local.MusicCapsuleDatabase
import com.musiccapsule.app.data.remote.gemini.GeminiApi
import com.musiccapsule.app.data.remote.spotify.SpotifyApi
import com.musiccapsule.app.data.repository.ArtistRepository
import com.musiccapsule.app.data.repository.StatsRepository
import com.musiccapsule.app.data.settings.SettingsRepository
import com.musiccapsule.app.tracking.CoverCache
import com.musiccapsule.app.tracking.PlaybackStateMachine
import kotlinx.serialization.json.Json

/**
 * Ручной DI-контейнер: единая точка сборки графа зависимостей приложения.
 * Живёт в Application и разделяется между UI и фоновым сервисом.
 */
class AppContainer(context: Context) {

    val json: Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    val database: MusicCapsuleDatabase = Room.databaseBuilder(
        context,
        MusicCapsuleDatabase::class.java,
        "music_capsule.db",
    ).fallbackToDestructiveMigration().build()

    val settingsRepository = SettingsRepository(context)
    val coverCache = CoverCache(context)

    val spotifyApi = SpotifyApi(json)
    val geminiApi = GeminiApi(json)

    val statsRepository = StatsRepository(
        playbackDao = database.playbackDao(),
    )
    val artistRepository = ArtistRepository(
        artistDao = database.artistDao(),
        spotifyApi = spotifyApi,
        geminiApi = geminiApi,
        settingsRepository = settingsRepository,
    )

    /** Единый стейт-автомат сессий прослушивания (используется фоновым сервисом). */
    val stateMachine = PlaybackStateMachine(
        playbackDao = database.playbackDao(),
        artistDao = database.artistDao(),
        coverCache = coverCache,
    )
}
