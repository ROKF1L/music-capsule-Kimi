package com.musiccapsule.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.musiccapsule.app.core.di.AppContainer
import com.musiccapsule.app.core.util.viewModelFactory
import com.musiccapsule.app.ui.capsule.CapsuleScreen
import com.musiccapsule.app.ui.capsule.CapsuleViewModel
import com.musiccapsule.app.ui.dashboard.DashboardScreen
import com.musiccapsule.app.ui.dashboard.DashboardViewModel
import com.musiccapsule.app.ui.history.HistoryScreen
import com.musiccapsule.app.ui.history.HistoryViewModel
import com.musiccapsule.app.ui.settings.SettingsScreen
import com.musiccapsule.app.ui.settings.SettingsViewModel

object Routes {
    const val DASHBOARD = "dashboard"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val CAPSULE = "capsule/{year}/{month}"
    fun capsule(year: Int, month: Int) = "capsule/$year/$month"
}

@Composable
fun AppNavGraph(container: AppContainer) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {

        composable(Routes.DASHBOARD) {
            val vm: DashboardViewModel = viewModel(
                factory = viewModelFactory { DashboardViewModel(container.statsRepository) },
            )
            DashboardScreen(
                viewModel = vm,
                onOpenHistory = { navController.navigate(Routes.HISTORY) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenCapsule = { ym ->
                    navController.navigate(Routes.capsule(ym.year, ym.monthValue))
                },
            )
        }

        composable(Routes.HISTORY) {
            val vm: HistoryViewModel = viewModel(
                factory = viewModelFactory { HistoryViewModel(container.statsRepository) },
            )
            HistoryScreen(viewModel = vm, onBack = { navController.popBackStack() })
        }

        composable(Routes.SETTINGS) {
            val vm: SettingsViewModel = viewModel(
                factory = viewModelFactory { SettingsViewModel(container.settingsRepository) },
            )
            SettingsScreen(viewModel = vm, onBack = { navController.popBackStack() })
        }

        composable(
            route = Routes.CAPSULE,
            arguments = listOf(
                navArgument("year") { type = NavType.IntType },
                navArgument("month") { type = NavType.IntType },
            ),
        ) { entry ->
            val year = entry.arguments?.getInt("year") ?: return@composable
            val month = entry.arguments?.getInt("month") ?: return@composable
            val vm: CapsuleViewModel = viewModel(
                factory = viewModelFactory {
                    CapsuleViewModel(
                        container.statsRepository,
                        container.artistRepository,
                        year, month,
                    )
                },
            )
            CapsuleScreen(viewModel = vm, onBack = { navController.popBackStack() })
        }
    }
}
