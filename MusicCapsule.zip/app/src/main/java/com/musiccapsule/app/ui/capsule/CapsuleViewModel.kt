package com.musiccapsule.app.ui.capsule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musiccapsule.app.data.repository.ArtistRepository
import com.musiccapsule.app.data.repository.StatsRepository
import com.musiccapsule.app.domain.model.MonthlyCapsule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class CapsuleUiState(
    val loading: Boolean = true,
    val capsule: MonthlyCapsule? = null,
    val roast: String = "",
    val archetype: String = "",
    val caption: String = "",
)

class CapsuleViewModel(
    private val statsRepository: StatsRepository,
    private val artistRepository: ArtistRepository,
    private val year: Int,
    private val month: Int,
) : ViewModel() {

    private val _state = MutableStateFlow(CapsuleUiState())
    val state: StateFlow<CapsuleUiState> = _state.asStateFlow()

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }

            // 1. Локальная аналитика из Room — работает полностью офлайн
            val capsule = statsRepository.monthlyCapsule(year, month)

            // 2. Фото артистов из Spotify (при офлайне вернутся ссылки из кэша Room)
            val meta = artistRepository.enrichArtists(
                capsule.topArtists.map { it.normalized to it.displayName },
            )
            val enriched = capsule.copy(
                topArtists = capsule.topArtists.map { artist ->
                    val m = meta[artist.normalized]
                    artist.copy(
                        imageUrl = m?.spotifyImageUrl,
                        genres = m?.genres,
                        displayName = m?.displayName ?: artist.displayName,
                    )
                },
            )

            // 3. Тексты от Gemini: прожарка + архетип (офлайн — локальный фолбэк)
            val monthName = YearMonth.of(year, month)
                .format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale("ru")))
            val texts = artistRepository.generateMonthlyTexts(enriched, monthName)

            _state.update {
                it.copy(
                    loading = false,
                    capsule = enriched,
                    roast = texts.roast,
                    archetype = texts.archetype,
                    caption = texts.caption,
                )
            }
        }
    }
}
