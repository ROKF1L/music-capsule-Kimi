package com.musiccapsule.app.domain.model

import com.musiccapsule.app.core.util.TimeSlot
import java.time.LocalDate
import java.time.YearMonth

data class DayActivity(val date: LocalDate, val minutes: Long)

data class TopTrack(
    val title: String,
    val artist: String,
    val plays: Long,
    val totalMs: Long,
    val coverPath: String?,
)

data class TopArtist(
    val normalized: String,
    val displayName: String,
    val plays: Long,
    val totalMs: Long,
    /** Сколько месяцев подряд артист в Топ-5. */
    val monthStreak: Int,
    val imageUrl: String?,
    val genres: String?,
)

data class LoopObsession(
    val title: String,
    val artist: String,
    val plays: Long,
    val hourBucket: String,
)

data class SlotStat(val slot: TimeSlot, val ms: Long)

/** Собранная капсула месяца — всё, что нужно для слайдов. */
data class MonthlyCapsule(
    val yearMonth: YearMonth,
    val totalMinutes: Long,
    val trackCount: Long,
    val mostActiveDay: LocalDate?,
    val mostActiveDayMinutes: Long,
    val averagePerDayMinutes: Long,
    val topTracks: List<TopTrack>,
    val topArtists: List<TopArtist>,
    val slotStats: List<SlotStat>,
    val chronotype: String,
    val loops: List<LoopObsession>,
    /** FLAC Flex: оценка объёма несжатого аудио в ГБ. */
    val flacGb: Double,
)

data class DashboardData(
    val streak: Int,
    val heatmap: List<DayActivity>,
    val todayMinutes: Long,
    val monthMinutes: Long,
    /** За какой месяц уже можно открыть капсулу (null — данных ещё нет). */
    val capsuleMonth: YearMonth?,
)

/** Тексты капсулы от Gemini (или локальный фолбэк при офлайне). */
data class GeminiTexts(
    val roast: String,
    val archetype: String,
    val caption: String,
)
