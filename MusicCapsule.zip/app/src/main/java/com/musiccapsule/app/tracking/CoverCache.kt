package com.musiccapsule.app.tracking

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.math.roundToInt

/**
 * Локальный кэш обложек: перехваченные из медиа-метаданных Bitmap
 * сохраняются в filesDir/covers/{md5}.jpg как миниатюры до 512px.
 */
class CoverCache(private val context: Context) {

    suspend fun save(key: String, bitmap: Bitmap): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "covers").apply { mkdirs() }
            val file = File(dir, md5(key) + ".jpg")
            if (!file.exists()) {
                val ratio = 512f / maxOf(bitmap.width, bitmap.height)
                val scaled = if (ratio < 1f) {
                    Bitmap.createScaledBitmap(
                        bitmap,
                        (bitmap.width * ratio).roundToInt().coerceAtLeast(1),
                        (bitmap.height * ratio).roundToInt().coerceAtLeast(1),
                        true,
                    )
                } else bitmap
                FileOutputStream(file).use { out ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
            }
            file.absolutePath
        }.getOrNull()
    }

    private fun md5(text: String): String =
        MessageDigest.getInstance("MD5")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
