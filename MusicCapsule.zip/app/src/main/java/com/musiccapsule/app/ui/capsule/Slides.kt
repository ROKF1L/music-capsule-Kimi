package com.musiccapsule.app.ui.capsule

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.musiccapsule.app.domain.model.MonthlyCapsule
import com.musiccapsule.app.ui.dashboard.monthName
import java.io.File
import java.time.format.DateTimeFormatter
import java.util.Locale

// Общие текстовые цвета поверх градиента
private val onGradient = Color.White
private val onGradientDim = Color.White.copy(alpha = 0.75f)

/** Слайд 1: общее время + самый активный день. */
@Composable
fun SlideIntro(capsule: MonthlyCapsule, caption: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            caption.ifBlank { "Твой ${monthName(capsule.yearMonth)} в музыке" },
            style = MaterialTheme.typography.titleMedium,
            color = onGradientDim,
        )
        Spacer(Modifier.height(24.dp))
        Text(
            "${capsule.totalMinutes}",
            fontSize = 96.sp,
            fontWeight = FontWeight.Black,
            color = onGradient,
        )
        Text("минут музыки", style = MaterialTheme.typography.titleLarge, color = onGradient)
        Spacer(Modifier.height(32.dp))
        capsule.mostActiveDay?.let { day ->
            Text(
                "Самый активный день",
                style = MaterialTheme.typography.labelLarge,
                color = onGradientDim,
            )
            Text(
                "${day.format(DateTimeFormatter.ofPattern("d MMMM", Locale("ru")))} — " +
                    "${capsule.mostActiveDayMinutes} мин",
                style = MaterialTheme.typography.titleMedium,
                color = onGradient,
            )
        }
        capsule.loops.firstOrNull()?.let { loop ->
            Spacer(Modifier.height(16.dp))
            Text(
                "Рекорд зацикливания: «${loop.title}» × ${loop.plays} за час",
                style = MaterialTheme.typography.bodySmall,
                color = onGradientDim,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "FLAC Flex: %.1f ГБ несжатого аудио".format(capsule.flacGb),
            style = MaterialTheme.typography.labelLarge,
            color = onGradientDim,
        )
    }
}

/** Слайд 2: Топ-5 треков с локальными обложками. */
@Composable
fun SlideTopTracks(capsule: MonthlyCapsule) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(
            "Топ-5 треков",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = onGradient,
        )
        Spacer(Modifier.height(24.dp))
        capsule.topTracks.forEachIndexed { index, track ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${index + 1}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = onGradientDim,
                    modifier = Modifier.width(32.dp),
                )
                if (track.coverPath != null) {
                    AsyncImage(
                        model = File(track.coverPath),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)),
                    )
                } else {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.MusicNote, null, tint = onGradient) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        track.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = onGradient,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = onGradientDim,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("×${track.plays}", style = MaterialTheme.typography.titleMedium, color = onGradient)
            }
        }
    }
}

/** Слайд 3: Топ-5 артистов с фото Spotify и бейджами стриков. */
@Composable
fun SlideTopArtists(capsule: MonthlyCapsule) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(
            "Топ-5 артистов",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = onGradient,
        )
        Spacer(Modifier.height(24.dp))
        capsule.topArtists.forEachIndexed { index, artist ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${index + 1}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = onGradientDim,
                    modifier = Modifier.width(32.dp),
                )
                if (artist.imageUrl != null) {
                    AsyncImage(
                        model = artist.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(52.dp).clip(CircleShape),
                    )
                } else {
                    Box(
                        Modifier.size(52.dp).clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Person, null, tint = onGradient) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        artist.displayName,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = onGradient,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        artist.genres ?: "${artist.plays} прослушиваний",
                        style = MaterialTheme.typography.bodySmall,
                        color = onGradientDim,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                // Бейдж стрика: "N мес. в топе"
                if (artist.monthStreak > 1) {
                    Surface(
                        color = Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(
                            "${artist.monthStreak} мес. в топе",
                            style = MaterialTheme.typography.labelSmall,
                            color = onGradient,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Слайд 4: биоритм (хронотип) + архетип и прожарка от Gemini. */
@Composable
fun SlideChronotype(capsule: MonthlyCapsule, archetype: String, roast: String) {
    val maxSlotMs = (capsule.slotStats.maxOfOrNull { it.ms } ?: 1L).coerceAtLeast(1L)
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(
            "Музыкальный биоритм",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = onGradient,
        )
        Spacer(Modifier.height(20.dp))
        // Бары по 4 временным слотам
        capsule.slotStats.forEach { stat ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stat.slot.label, color = onGradient, modifier = Modifier.width(56.dp))
                Box(
                    Modifier.weight(1f).height(14.dp).clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.2f)),
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth((stat.ms.toFloat() / maxSlotMs).coerceAtLeast(0.02f))
                            .height(14.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.White),
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    "${stat.ms / 60_000} мин",
                    style = MaterialTheme.typography.labelSmall,
                    color = onGradientDim,
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Хронотип: ${capsule.chronotype}", style = MaterialTheme.typography.titleLarge, color = onGradient)
        Spacer(Modifier.height(8.dp))
        Text(
            "Архетип месяца: $archetype",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = onGradient,
        )
        if (roast.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Surface(color = Color.Black.copy(alpha = 0.25f), shape = RoundedCornerShape(12.dp)) {
                Text(
                    roast,
                    style = MaterialTheme.typography.bodyMedium,
                    color = onGradient,
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
    }
}

/** Слайд 5: итоговая карточка (её же экспортируем в PNG). */
@Composable
fun SlideSummary(capsule: MonthlyCapsule, archetype: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ShareCard(capsule, archetype)
    }
}

/** Итоговая карточка — отдельный компонент, чтобы переиспользовать при экспорте. */
@Composable
fun ShareCard(capsule: MonthlyCapsule, archetype: String) {
    Surface(
        color = Color.Black.copy(alpha = 0.3f),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(
            Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                monthName(capsule.yearMonth).uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = onGradientDim,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "${capsule.totalMinutes}",
                fontSize = 72.sp,
                fontWeight = FontWeight.Black,
                color = onGradient,
            )
            Text("минут", color = onGradient)
            Spacer(Modifier.height(16.dp))
            capsule.topArtists.firstOrNull()?.let {
                Text("Артист месяца: ${it.displayName}", color = onGradient, fontWeight = FontWeight.SemiBold)
            }
            capsule.topTracks.firstOrNull()?.let {
                Text("Трек месяца: ${it.title}", color = onGradientDim, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            Text(archetype, color = onGradient, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(12.dp))
            Text(
                "Music Capsule",
                style = MaterialTheme.typography.labelSmall,
                color = onGradientDim,
            )
        }
    }
}
