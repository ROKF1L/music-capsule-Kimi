package com.musiccapsule.app.core.util

/** Временные слоты музыкальных биоритмов. */
enum class TimeSlot(val label: String) {
    MORNING("Утро"),
    DAY("День"),
    EVENING("Вечер"),
    NIGHT("Ночь");

    companion object {
        fun of(hour: Int): TimeSlot = when (hour) {
            in 6..11 -> MORNING   // 06:00–12:00
            in 12..17 -> DAY      // 12:00–18:00
            in 18..22 -> EVENING  // 18:00–23:00
            else -> NIGHT         // 23:00–06:00
        }
    }
}
