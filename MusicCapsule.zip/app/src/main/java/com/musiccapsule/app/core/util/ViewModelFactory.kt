package com.musiccapsule.app.core.util

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

/** Лёгкая фабрика ViewModel без внешнего DI-фреймворка. */
inline fun <reified VM : ViewModel> viewModelFactory(
    crossinline creator: () -> VM,
): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return creator() as T
    }
}
