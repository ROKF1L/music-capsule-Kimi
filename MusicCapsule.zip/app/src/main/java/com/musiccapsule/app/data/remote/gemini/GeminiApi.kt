package com.musiccapsule.app.data.remote.gemini

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

// ---- DTO ----

@Serializable
private data class GeminiRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
)

@Serializable
private data class Content(val parts: List<Part>)

@Serializable
private data class Part(val text: String? = null)

@Serializable
private data class GenerationConfig(val temperature: Double = 0.9)

@Serializable
private data class GeminiResponse(val candidates: List<Candidate>? = null)

@Serializable
private data class Candidate(val content: Content? = null)

/**
 * Google Gemini API (generateContent).
 * Применения: группировка вариантов написания артистов и генерация текстов капсулы.
 */
class GeminiApi(private val json: Json) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun generateText(apiKey: String, prompt: String): String? =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext null
            runCatching {
                val requestBody = GeminiRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                )
                val body = json.encodeToString(GeminiRequest.serializer(), requestBody)
                    .toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(
                        "https://generativelanguage.googleapis.com/v1beta/" +
                            "models/gemini-2.0-flash:generateContent?key=$apiKey"
                    )
                    .post(body)
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@runCatching null
                    val parsed = json.decodeFromString<GeminiResponse>(response.body.string())
                    parsed.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                }
            }.getOrNull() // Офлайн / лимит API -> null, UI покажет локальный фолбэк
        }

    /**
     * Группировка вариантов написания артистов:
     * "kairiki bear", "Kairikibear", "かいりきベア" -> "かいりきベア" (каноничное имя).
     * Возвращает маппинг "исходное имя" -> "каноничное имя".
     */
    suspend fun normalizeArtistNames(apiKey: String, names: List<String>): Map<String, String> {
        if (names.isEmpty()) return emptyMap()
        val prompt = buildString {
            append("Ты — музыкальный эксперт. Ниже список имён исполнителей из тегов аудиофайлов ")
            append("(разные языки, регистры и транслитерации).\n")
            append("Сгруппируй варианты одного и того же исполнителя и выбери каноничное ")
            append("написание (как в Spotify).\n")
            append("Ответь СТРОГО одним JSON-объектом без пояснений и markdown-обёртки: ")
            append("{\"<исходное имя>\": \"<каноничное имя>\"}.\nСписок:\n")
            names.take(200).forEach { append("- ").append(it).append('\n') }
        }
        val text = generateText(apiKey, prompt) ?: return emptyMap()
        return parseMapping(text)
    }

    /** Достаём JSON-объект из ответа модели (она любит оборачивать его в ```json). */
    private fun parseMapping(text: String): Map<String, String> = runCatching {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return emptyMap()
        Json.parseToJsonElement(text.substring(start, end + 1))
            .jsonObject
            .mapValues { it.value.jsonPrimitive.content }
    }.getOrDefault(emptyMap())
}
