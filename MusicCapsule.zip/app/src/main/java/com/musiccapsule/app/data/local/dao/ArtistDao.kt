package com.musiccapsule.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import com.musiccapsule.app.data.local.entity.ArtistAliasEntity
import com.musiccapsule.app.data.local.entity.ArtistMetadataEntity

@Dao
interface ArtistDao {

    // ---- Метаданные артистов (кэш Spotify) ----

    @Upsert
    suspend fun upsertMetadata(meta: ArtistMetadataEntity)

    @Query("SELECT * FROM artist_metadata WHERE normalized_artist = :key")
    suspend fun getMetadata(key: String): ArtistMetadataEntity?

    // ---- Алиасы (Gemini-нормализация написаний) ----

    @Query("SELECT canonical_name FROM artist_aliases WHERE raw_alias = :raw")
    suspend fun resolveAlias(raw: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAliases(aliases: List<ArtistAliasEntity>)

    @Query("SELECT raw_alias FROM artist_aliases")
    suspend fun allKnownAliases(): List<String>
}
