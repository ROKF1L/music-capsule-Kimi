package com.musiccapsule.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.musiccapsule.app.domain.model.DayActivity

/**
 * GitHub-style тепловая карта: 52 недели колонками по 7 дней (Пн сверху).
 */
@Composable
fun ActivityHeatmap(days: List<DayActivity>, modifier: Modifier = Modifier) {
    // Дополняем первую неделю пустыми ячейками до понедельника и бьём на колонки
    val weeks: List<List<DayActivity?>> = remember(days) {
        if (days.isEmpty()) return@remember emptyList()
        val offset = days.first().date.dayOfWeek.value - 1 // Пн = 0
        val padded = List<DayActivity?>(offset) { null } + days.map { it }
        padded.chunked(7)
    }
    val maxMinutes = (days.maxOfOrNull { it.minutes } ?: 0L).coerceAtLeast(1L)
    val listState = rememberLazyListState()

    // Открываем карту сразу прокрученной к сегодняшнему дню
    LaunchedEffect(weeks.size) {
        if (weeks.isNotEmpty()) listState.scrollToItem(weeks.size - 1)
    }

    Column(modifier = modifier) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            items(weeks) { week ->
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    week.forEach { day ->
                        val color = when {
                            day == null || day.minutes == 0L ->
                                MaterialTheme.colorScheme.surfaceVariant
                            else -> {
                                // 4 уровня интенсивности по квартилям от максимума
                                val level = (day.minutes * 4 / maxMinutes).coerceIn(1, 4)
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.25f * level)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(11.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(color),
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("365 дней", style = MaterialTheme.typography.labelSmall)
            Text(
                "Меньше → Больше",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
