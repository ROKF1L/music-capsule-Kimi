package com.musiccapsule.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musiccapsule.app.data.settings.AppSettings
import com.musiccapsule.app.data.settings.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: SettingsRepository,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun saveApiKeys(spotifyId: String, spotifySecret: String, geminiKey: String) {
        viewModelScope.launch { repository.saveApiKeys(spotifyId, spotifySecret, geminiKey) }
    }

    fun setPackageBlocked(packageName: String, blocked: Boolean) {
        viewModelScope.launch { repository.setPackageBlocked(packageName, blocked) }
    }
}
