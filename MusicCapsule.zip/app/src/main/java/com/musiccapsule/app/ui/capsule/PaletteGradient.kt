package com.musiccapsule.app.ui.capsule

import android.graphics.drawable.BitmapDrawable
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.palette.graphics.Palette
import coil.ImageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Динамический градиент фона капсулы: палитра извлекается из локальной обложки
 * трека (vibrant + darkMuted), фолбэк — цвета темы.
 */
@Composable
fun rememberCoverGradient(coverPath: String?): Brush {
    val context = LocalContext.current
    var paletteColors by remember(coverPath) { mutableStateOf<List<Color>?>(null) }

    LaunchedEffect(coverPath) {
        if (coverPath == null) return@LaunchedEffect
        // Загрузка битмапы и анализ палитры — строго на IO/Default
        val bitmap = withContext(Dispatchers.IO) {
            runCatching {
                val request = ImageRequest.Builder(context)
                    .data(File(coverPath))
                    .allowHardware(false) // Palette нужен софтверный Bitmap
                    .size(256)
                    .build()
                (ImageLoader(context).execute(request).drawable as? BitmapDrawable)?.bitmap
            }.getOrNull()
        } ?: return@LaunchedEffect

        val palette = withContext(Dispatchers.Default) {
            Palette.from(bitmap).generate()
        }
        val extracted = listOfNotNull(
            palette.vibrantSwatch?.rgb,
            palette.darkMutedSwatch?.rgb ?: palette.dominantSwatch?.rgb,
            palette.darkVibrantSwatch?.rgb,
        ).distinct().map { Color(it) }
        if (extracted.isNotEmpty()) paletteColors = extracted
    }

    val fallback = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.tertiary,
        MaterialTheme.colorScheme.surface,
    )
    return Brush.verticalGradient(paletteColors ?: fallback)
}
