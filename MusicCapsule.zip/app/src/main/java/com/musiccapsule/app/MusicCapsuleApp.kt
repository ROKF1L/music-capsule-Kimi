package com.musiccapsule.app

import android.app.Application
import com.musiccapsule.app.core.di.AppContainer

class MusicCapsuleApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
