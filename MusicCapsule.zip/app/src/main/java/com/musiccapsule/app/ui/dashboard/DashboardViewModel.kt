package com.musiccapsule.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musiccapsule.app.data.repository.StatsRepository
import com.musiccapsule.app.domain.model.DayActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.YearMonth

data class DashboardUiState(
    val loading: Boolean = true,
    val streak: Int = 0,
    val heatmap: List<DayActivity> = emptyList(),
    val todayMinutes: Long = 0,
    val monthMinutes: Long = 0,
    val capsuleMonth: YearMonth? = null,
)

class DashboardViewModel(
    private val statsRepository: StatsRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            val data = statsRepository.dashboard()
            _state.value = DashboardUiState(
                loading = false,
                streak = data.streak,
                heatmap = data.heatmap,
                todayMinutes = data.todayMinutes,
                monthMinutes = data.monthMinutes,
                capsuleMonth = data.capsuleMonth,
            )
        }
    }
}
