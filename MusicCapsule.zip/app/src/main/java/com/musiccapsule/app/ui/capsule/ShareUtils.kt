package com.musiccapsule.app.ui.capsule

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.FileProvider
import androidx.core.view.doOnPreDraw
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume

/** Экспорт Compose-компонента в Bitmap и шеринг через FileProvider. */
object ShareUtils {

    /**
     * Рендерит произвольный @Composable в Bitmap заданного размера.
     * Невидимая ComposeView добавляется в иерархию за пределами экрана,
     * дожидаемся первого кадра (doOnPreDraw) и рисуем её в Canvas.
     */
    suspend fun captureComposable(
        activity: Activity,
        widthPx: Int,
        heightPx: Int,
        content: @Composable () -> Unit,
    ): Bitmap? = suspendCancellableCoroutine { continuation ->
        val parent = activity.window.decorView as ViewGroup
        val view = ComposeView(activity).apply {
            translationX = -10000f // рендерится, но не видна пользователю
            setContent { content() }
        }
        parent.addView(view, ViewGroup.LayoutParams(widthPx, heightPx))
        view.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY),
        )
        view.layout(0, 0, widthPx, heightPx)
        view.doOnPreDraw {
            val result = runCatching {
                Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888).also { bitmap ->
                    view.draw(Canvas(bitmap))
                }
            }.getOrNull()
            parent.removeView(view)
            if (continuation.isActive) continuation.resume(result)
        }
        continuation.invokeOnCancellation { runCatching { parent.removeView(view) } }
    }

    /** Сохранение PNG в cacheDir/shared и системный диалог "Поделиться". */
    fun shareBitmap(context: Context, bitmap: Bitmap, fileName: String = "music_capsule.png") {
        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Поделиться капсулой"))
    }
}
