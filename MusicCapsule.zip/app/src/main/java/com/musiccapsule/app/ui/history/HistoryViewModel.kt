package com.musiccapsule.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musiccapsule.app.data.local.entity.PlaybackEventEntity
import com.musiccapsule.app.data.repository.StatsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val statsRepository: StatsRepository,
) : ViewModel() {

    val events: StateFlow<List<PlaybackEventEntity>> = statsRepository
        .observeHistory(limit = 1000)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Исключить/вернуть трек в аналитику капсулы (мягкое исключение). */
    fun toggleExcluded(event: PlaybackEventEntity) {
        viewModelScope.launch {
            statsRepository.setExcluded(event.id, !event.isExcluded)
        }
    }

    /** Полное удаление записи из базы. */
    fun delete(event: PlaybackEventEntity) {
        viewModelScope.launch {
            statsRepository.deleteEvent(event.id)
        }
    }
}
