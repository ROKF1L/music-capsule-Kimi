package com.musiccapsule.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.musiccapsule.app.data.local.dao.ArtistDao
import com.musiccapsule.app.data.local.dao.PlaybackDao
import com.musiccapsule.app.data.local.entity.ArtistAliasEntity
import com.musiccapsule.app.data.local.entity.ArtistMetadataEntity
import com.musiccapsule.app.data.local.entity.PlaybackEventEntity

@Database(
    entities = [
        PlaybackEventEntity::class,
        ArtistMetadataEntity::class,
        ArtistAliasEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class MusicCapsuleDatabase : RoomDatabase() {
    abstract fun playbackDao(): PlaybackDao
    abstract fun artistDao(): ArtistDao
}
