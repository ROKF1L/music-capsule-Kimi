package com.musiccapsule.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.musiccapsule.app.data.local.entity.PlaybackEventEntity
import kotlinx.coroutines.flow.Flow

// ---- Проекции для аналитических запросов ----

data class DayTotal(val day: String, val totalMs: Long)
data class HourTotal(val hour: Int, val totalMs: Long)

data class TopTrackRow(
    val trackTitle: String,
    val artistName: String,
    val plays: Long,
    val totalMs: Long,
    val coverPath: String?,
)

data class TopArtistRow(
    val normalizedArtist: String,
    val displayName: String,
    val plays: Long,
    val totalMs: Long,
)

data class LoopRow(
    val trackTitle: String,
    val artistName: String,
    val hourBucket: String,
    val plays: Long,
)

@Dao
interface PlaybackDao {

    @Insert
    suspend fun insert(event: PlaybackEventEntity): Long

    @Query("UPDATE playback_events SET is_excluded = :excluded WHERE id = :id")
    suspend fun setExcluded(id: Long, excluded: Boolean)

    @Query("DELETE FROM playback_events WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM playback_events ORDER BY timestamp DESC LIMIT :limit")
    fun observeHistory(limit: Int): Flow<List<PlaybackEventEntity>>

    /** Суммарные миллисекунды по дням (для стриков и тепловой карты). */
    @Query(
        """
        SELECT date(timestamp / 1000, 'unixepoch', 'localtime') AS day,
               SUM(duration_ms) AS totalMs
        FROM playback_events
        WHERE is_excluded = 0 AND is_sleep_session = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        GROUP BY day
        """
    )
    suspend fun dayTotals(fromMs: Long, toMs: Long): List<DayTotal>

    /** Топ треков за период. */
    @Query(
        """
        SELECT track_title AS trackTitle,
               artist_name AS artistName,
               COUNT(*) AS plays,
               SUM(duration_ms) AS totalMs,
               MAX(cover_path) AS coverPath
        FROM playback_events
        WHERE is_excluded = 0 AND is_sleep_session = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        GROUP BY track_title, artist_name
        ORDER BY plays DESC, totalMs DESC
        LIMIT :limit
        """
    )
    suspend fun topTracks(fromMs: Long, toMs: Long, limit: Int): List<TopTrackRow>

    /** Топ артистов за период (группировка по нормализованному ключу). */
    @Query(
        """
        SELECT normalized_artist AS normalizedArtist,
               MAX(artist_name) AS displayName,
               COUNT(*) AS plays,
               SUM(duration_ms) AS totalMs
        FROM playback_events
        WHERE is_excluded = 0 AND is_sleep_session = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        GROUP BY normalized_artist
        ORDER BY plays DESC, totalMs DESC
        LIMIT :limit
        """
    )
    suspend fun topArtists(fromMs: Long, toMs: Long, limit: Int): List<TopArtistRow>

    /** Активность по часам суток (музыкальные биоритмы). */
    @Query(
        """
        SELECT CAST(strftime('%H', timestamp / 1000, 'unixepoch', 'localtime') AS INTEGER) AS hour,
               SUM(duration_ms) AS totalMs
        FROM playback_events
        WHERE is_excluded = 0 AND is_sleep_session = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        GROUP BY hour
        """
    )
    suspend fun minutesByHour(fromMs: Long, toMs: Long): List<HourTotal>

    /** Детектор зацикливания: треки, прослушанные более 4 раз за один час. */
    @Query(
        """
        SELECT track_title AS trackTitle,
               artist_name AS artistName,
               strftime('%Y-%m-%d %H', timestamp / 1000, 'unixepoch', 'localtime') AS hourBucket,
               COUNT(*) AS plays
        FROM playback_events
        WHERE is_excluded = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        GROUP BY hourBucket, track_title, artist_name
        HAVING COUNT(*) > 4
        ORDER BY plays DESC
        LIMIT 5
        """
    )
    suspend fun loopObsessions(fromMs: Long, toMs: Long): List<LoopRow>

    @Query(
        """
        SELECT SUM(duration_ms) FROM playback_events
        WHERE is_excluded = 0 AND is_sleep_session = 0
          AND timestamp BETWEEN :fromMs AND :toMs
        """
    )
    suspend fun totalListenedMs(fromMs: Long, toMs: Long): Long?

    @Query(
        """
        SELECT COUNT(*) FROM playback_events
        WHERE is_excluded = 0 AND timestamp BETWEEN :fromMs AND :toMs
        """
    )
    suspend fun countEvents(fromMs: Long, toMs: Long): Long

    /** Все различные «сырые» имена артистов за период (для Gemini-нормализации). */
    @Query(
        """
        SELECT DISTINCT artist_name FROM playback_events
        WHERE timestamp BETWEEN :fromMs AND :toMs
        """
    )
    suspend fun distinctRawArtists(fromMs: Long, toMs: Long): List<String>
}
