package com.musiccapsule.app.data.repository

import com.musiccapsule.app.core.util.ArtistNormalizer
import com.musiccapsule.app.data.local.dao.ArtistDao
import com.musiccapsule.app.data.local.entity.ArtistAliasEntity
import com.musiccapsule.app.data.local.entity.ArtistMetadataEntity
import com.musiccapsule.app.data.remote.gemini.GeminiApi
import com.musiccapsule.app.data.remote.spotify.SpotifyApi
import com.musiccapsule.app.data.settings.SettingsRepository
import com.musiccapsule.app.domain.model.GeminiTexts
import com.musiccapsule.app.domain.model.MonthlyCapsule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/** Метаданные артистов: Spotify-фото/жанры с кэшем в Room + Gemini-тексты и алиасы. */
class ArtistRepository(
    private val artistDao: ArtistDao,
    private val spotifyApi: SpotifyApi,
    private val geminiApi: GeminiApi,
    private val settingsRepository: SettingsRepository,
) {

    private val cacheTtlMs = TimeUnit.DAYS.toMillis(30)

    /**
     * Подтягивает фото и жанры артистов из Spotify и кэширует ссылки в Room.
     * Офлайн-сценарий: при отсутствии сети/ключей возвращается то, что есть в кэше.
     * @param artists пары (нормализованный ключ -> отображаемое имя)
     */
    suspend fun enrichArtists(
        artists: List<Pair<String, String>>,
    ): Map<String, ArtistMetadataEntity> = withContext(Dispatchers.IO) {
        val settings = settingsRepository.settings.first()
        val result = LinkedHashMap<String, ArtistMetadataEntity>()
        val now = System.currentTimeMillis()

        for ((normalized, display) in artists) {
            val cached = artistDao.getMetadata(normalized)
            val cacheFresh = cached != null && now - cached.lastUpdated < cacheTtlMs

            when {
                cacheFresh -> result[normalized] = cached!!
                settings.spotifyClientId.isBlank() || settings.spotifyClientSecret.isBlank() -> {
                    // Ключи не заданы — работаем на том, что уже закэшировано
                    cached?.let { result[normalized] = it }
                }
                else -> {
                    val remote = spotifyApi.searchArtist(
                        display, settings.spotifyClientId, settings.spotifyClientSecret,
                    )
                    val entity = ArtistMetadataEntity(
                        normalizedArtist = normalized,
                        displayName = remote?.name ?: display,
                        spotifyImageUrl = remote?.imageUrl ?: cached?.spotifyImageUrl,
                        genres = remote?.genres ?: cached?.genres,
                        lastUpdated = now,
                    )
                    artistDao.upsertMetadata(entity)
                    result[normalized] = entity
                }
            }
        }
        result
    }

    /**
     * Gemini-нормализация: сырой список имён из тегов -> таблица алиасов
     * (raw_alias -> canonical_name), которую стейт-машина применяет при записи событий.
     */
    suspend fun normalizeAliases(rawNames: List<String>) = withContext(Dispatchers.IO) {
        val apiKey = settingsRepository.settings.first().geminiApiKey
        if (apiKey.isBlank()) return@withContext

        val known = artistDao.allKnownAliases().toHashSet()
        val unknown = rawNames
            .map { it.trim() }
            .filter { it.isNotEmpty() && ArtistNormalizer.normalize(it) !in known }
            .distinct()
        if (unknown.isEmpty()) return@withContext

        val mapping = geminiApi.normalizeArtistNames(apiKey, unknown)
        if (mapping.isEmpty()) return@withContext

        artistDao.insertAliases(
            mapping.map { (raw, canonical) ->
                ArtistAliasEntity(
                    rawAlias = ArtistNormalizer.normalize(raw),
                    canonicalName = ArtistNormalizer.normalize(canonical),
                )
            }
        )
    }

    /**
     * Тексты капсулы от Gemini: прожарка вкуса + музыкальный архетип месяца.
     * При офлайне или пустом ключе — локальный фолбэк.
     */
    suspend fun generateMonthlyTexts(capsule: MonthlyCapsule, monthName: String): GeminiTexts =
        withContext(Dispatchers.IO) {
            val fallback = GeminiTexts(
                roast = localRoast(capsule),
                archetype = localArchetype(capsule),
                caption = "Твой $monthName в музыке",
            )
            val apiKey = settingsRepository.settings.first().geminiApiKey
            if (apiKey.isBlank()) return@withContext fallback

            val artistsList = capsule.topArtists.joinToString(", ") { it.displayName }
            val tracksList = capsule.topTracks.joinToString(", ") { "${it.title} — ${it.artist}" }

            val roast = geminiApi.generateText(
                apiKey,
                """
                Ты — остроумный музыкальный критик. Напиши короткую (2-3 предложения) добрую,
                но едкую прожарку музыкального вкуса слушателя по итогам месяца $monthName.
                Топ артистов: $artistsList. Топ треков: $tracksList.
                Всего минут: ${capsule.totalMinutes}. Хронотип: ${capsule.chronotype}.
                Пиши по-русски, иронично и дружелюбно, без заголовков.
                """.trimIndent(),
            )?.trim()

            val archetype = geminiApi.generateText(
                apiKey,
                """
                Придумай "музыкальный архетип месяца" для слушателя — короткий яркий титул
                из 2-4 слов (примеры: "Ночной андеграунд-шаман", "Лоуфай-романтик").
                Топ артистов: $artistsList. Хронотип: ${capsule.chronotype}.
                Ответь только самим архетипом, без кавычек и пояснений.
                """.trimIndent(),
            )?.trim()

            GeminiTexts(
                roast = roast?.takeIf { it.isNotBlank() } ?: fallback.roast,
                archetype = archetype?.takeIf { it.isNotBlank() } ?: fallback.archetype,
                caption = fallback.caption,
            )
        }

    // ---- Локальные фолбэки на случай офлайна ----

    private fun localRoast(capsule: MonthlyCapsule): String {
        val topArtist = capsule.topArtists.firstOrNull()?.displayName ?: "тишина"
        val loop = capsule.loops.firstOrNull()
        return buildString {
            append("${capsule.totalMinutes} минут за месяц — и львиная доля ушла на $topArtist. ")
            if (loop != null) {
                append("«${loop.title}» ты крутил ${loop.plays} раз за час — соседи уже выучили слова. ")
            }
            append("Хронотип: ${capsule.chronotype.lowercase()}. Вкус есть, тормозов нет.")
        }
    }

    private fun localArchetype(capsule: MonthlyCapsule): String = when (capsule.chronotype) {
        "Сова" -> "Ночной эмо-архивариус"
        "Жаворонок" -> "Утренний хаус-оптимист"
        else -> "Дневной плейлист-куратор"
    }
}
