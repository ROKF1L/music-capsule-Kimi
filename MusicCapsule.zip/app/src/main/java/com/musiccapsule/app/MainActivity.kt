package com.musiccapsule.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.musiccapsule.app.ui.navigation.AppNavGraph
import com.musiccapsule.app.ui.theme.MusicCapsuleTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as MusicCapsuleApp).container
        setContent {
            MusicCapsuleTheme {
                AppNavGraph(container)
            }
        }
    }
}
