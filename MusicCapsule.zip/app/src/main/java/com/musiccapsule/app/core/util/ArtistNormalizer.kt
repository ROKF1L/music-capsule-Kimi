package com.musiccapsule.app.core.util

/**
 * Нормализация имён исполнителей для устойчивой группировки.
 * "Kairiki bear" / "kairikibear" -> один и тот же ключ; экзотические варианты
 * ("かいりきベア") склеиваются через таблицу алиасов, которую заполняет Gemini.
 */
object ArtistNormalizer {

    private val featRegex = Regex("""(?i)\s*[([]?\b(feat\.?|ft\.?|featuring)\b.*""")

    /** Очищенный ключ: lowercase, без featuring, без спецсимволов и пробелов. */
    fun normalize(raw: String): String =
        raw.replace(featRegex, "")
            .lowercase()
            .replace(Regex("""[^\p{L}\p{N}]+"""), "")
            .trim()

    /** Человекочитаемое имя без featuring-суффиксов. */
    fun display(raw: String): String = raw.replace(featRegex, "").trim()
}
