package com.musiccapsule.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Одно засчитанное прослушивание (прошло порог 30 сек / 50% длительности). */
@Entity(
    tableName = "playback_events",
    indices = [Index("timestamp"), Index("normalized_artist")],
)
data class PlaybackEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "track_title")
    val trackTitle: String,

    @ColumnInfo(name = "artist_name")
    val artistName: String,

    /** Очищенный ключ без спецсимволов и пробелов в lowercase. */
    @ColumnInfo(name = "normalized_artist")
    val normalizedArtist: String,

    @ColumnInfo(name = "album_name")
    val albumName: String?,

    /** Сколько миллисекунд реально прослушано (время пауз не учитывается). */
    @ColumnInfo(name = "duration_ms")
    val durationMs: Long,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long,

    @ColumnInfo(name = "cover_path")
    val coverPath: String?,

    /** Исключено пользователем из аналитики капсулы. */
    @ColumnInfo(name = "is_excluded")
    val isExcluded: Boolean = false,

    /** Анти-сон: трек зациклен ночью > 3 часов при погашенном экране. */
    @ColumnInfo(name = "is_sleep_session")
    val isSleepSession: Boolean = false,

    /** Пакет плеера-источника (для белого/чёрного списка). */
    @ColumnInfo(name = "source_package")
    val sourcePackage: String? = null,
)

/** Кэш метаданных артиста из Spotify — позволяет капсуле открываться офлайн. */
@Entity(tableName = "artist_metadata")
data class ArtistMetadataEntity(
    @PrimaryKey
    @ColumnInfo(name = "normalized_artist")
    val normalizedArtist: String,

    @ColumnInfo(name = "display_name")
    val displayName: String,

    @ColumnInfo(name = "spotify_image_url")
    val spotifyImageUrl: String?,

    @ColumnInfo(name = "genres")
    val genres: String?,

    @ColumnInfo(name = "last_updated")
    val lastUpdated: Long,
)

/** Маппинг разных написаний исполнителя к единому каноничному имени. */
@Entity(tableName = "artist_aliases")
data class ArtistAliasEntity(
    @PrimaryKey
    @ColumnInfo(name = "raw_alias")
    val rawAlias: String,

    @ColumnInfo(name = "canonical_name")
    val canonicalName: String,
)
